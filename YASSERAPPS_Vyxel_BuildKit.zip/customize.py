#!/usr/bin/env python3
"""YASSERAPPS branding overlay for Vyxel Apps open-core (AGPL-3.0).
Run: python3 customize.py /path/to/vyxel-apps

Modifies a local source checkout; never touches GitHub repositories by itself.
Upstream source copyright remains with its author. YASSERAPPS owns its
independent icon, name and original branding edits.
"""
from __future__ import annotations
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
if ROOT is None or not (ROOT / 'app/build.gradle.kts').exists():
    raise SystemExit('Usage: python3 customize.py /path/to/cloned/vyxel-apps')

def replace_exact(path: str, old: str, new: str, *, min_count: int = 1):
    target = ROOT / path
    text = target.read_text(encoding='utf-8-sig')
    count = text.count(old)
    if count < min_count:
        raise RuntimeError(f'{path}: expected {old!r}, found {count}; upstream changed, review patch')
    target.write_text(text.replace(old,new),encoding='utf-8')
    print(f'[OK] {path}: {old[:40]!r} -> {new[:40]!r} ({count}x)')

# CRUCIAL: Change applicationId only. Android namespace + Kotlin package MUST remain
# com.vythera.vyxelapps or all R/BuildConfig references would need refactoring.
replace_exact('app/build.gradle.kts',
              'applicationId = "com.vythera.vyxelapps"',
              'applicationId = "com.yasserapps.store"')
# Debug builds are signed automatically and should install under our actual package.
replace_exact('app/build.gradle.kts',
              'applicationIdSuffix = ".opencore"',
              '// YASSERAPPS preview uses the real, independent applicationId')
replace_exact('app/build.gradle.kts',
              'versionNameSuffix = "-opencore"',
              'versionNameSuffix = "-yasserapps-preview"')
replace_exact('settings.gradle.kts', 'rootProject.name = "Vyxel Apps"', 'rootProject.name = "YASSERAPPS"')
replace_exact('app/src/main/res/values/strings.xml',
              '<string name="app_name">Vyxel Apps</string>',
              '<string name="app_name">YASSERAPPS</string>')

# Store branding in Kotlin user-facing texts (never rename classes, packages, or APIs).
for path in (ROOT / 'app/src/main/java').rglob('*.kt'):
    content = path.read_text(encoding='utf-8-sig')
    changed = content.replace('Vyxel Apps', 'YASSERAPPS')
    if changed != content:
        path.write_text(changed,encoding='utf-8')

# Android theme: black + neon green, no paid Liquid Glass pack.
colors = 'app/src/main/java/com/vythera/vyxelapps/expressive/ui/theme/Color.kt'
color_transforms = {
  'Color(0xFF20005C)': 'Color(0xFF1C2B00)',
  'Color(0xFF360091)': 'Color(0xFF314800)',
  'Color(0xFF4B1FC0)': 'Color(0xFF4B6D00)',
  'Color(0xFF6242E0)': 'Color(0xFF638C00)',
  'Color(0xFFCBBEFF)': 'Color(0xFFC7FF00)',
  'Color(0xFFE7DEFF)': 'Color(0xFFECFFB3)',
  'Color(0xFF101116)': 'Color(0xFF090A08)',
  'Color(0xFF16171D)': 'Color(0xFF10130D)',
  'Color(0xFF1B1C22)': 'Color(0xFF171C10)',
  'Color(0xFF22232A)': 'Color(0xFF202719)',
  'Color(0xFF2B2C33)': 'Color(0xFF283123)',
}
for old, new in color_transforms.items():
    replace_exact(colors, old, new)

# Brand palette on the classic layer as well.
classic_colors = 'app/src/main/res/values/colors.xml'
replace_exact(classic_colors, '#6C63FF', '#C7FF00')
replace_exact(classic_colors, '#FF6B35', '#A4D400')

# On first install make Expressive use AMOLED dark, giving black/neon identity.
settings = 'app/src/main/java/com/vythera/vyxelapps/expressive/data/SettingsStore.kt'
replace_exact(settings,
              'val themeMode: ThemeMode = ThemeMode.System,',
              'val themeMode: ThemeMode = ThemeMode.Amoled,')
replace_exact(settings, '?: ThemeMode.System,', '?: ThemeMode.Amoled,')

# Add a real action opening Yasser's Telegram channel in Expressive settings.
settings_screen = 'app/src/main/java/com/vythera/vyxelapps/expressive/ui/screens/SettingsScreen.kt'
sc = (ROOT/settings_screen).read_text(encoding='utf-8-sig')
anchor = """                    text = xs.aboutBlurb,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )"""
addition = """                    text = xs.aboutBlurb,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                ActionPill("YASSERAPPS • قناتنا على تيليجرام", Modifier.fillMaxWidth()) {
                    runCatching {
                        ctx.startActivity(android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://t.me/YasserAppsIQ")
                        ))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "© 2026 YASSERAPPS • Built on Vyxel Apps (AGPL-3.0)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )"""
if sc.count(anchor) != 1:
    raise RuntimeError('SettingsScreen.kt About section changed; needs manual review')
(ROOT/settings_screen).write_text(sc.replace(anchor,addition,1),encoding='utf-8')

# Launcher icon: use user-approved Y logo with safe margin.
for density in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
    icon_src = HERE / 'branding' / f'ic_launcher_foreground_{density}.png'
    icon_dst = ROOT / 'app/src/main/res' / f'mipmap-{density}' / 'ic_launcher_foreground.png'
    icon_dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(icon_src, icon_dst)
# Decorative store icon for listings (not used at runtime).
shutil.copy2(HERE/'branding/YASSERAPPS_icon_crop.png',ROOT/'app/src/main/ic_launcher-playstore.png')

# Clear legal statement replacing upstream's template NOTICE; original AGPL LICENSE stays.
(ROOT/'NOTICE').write_text("""YASSERAPPS — Android store rebrand of the Vyxel Apps open-core client

Original software: Vyxel Apps
Copyright (C) 2026 Nikhil
Source: https://github.com/NikhilKain/vyxel-apps
Original software license: GNU Affero General Public License v3.0 (AGPL-3.0)

YASSERAPPS brand name, user-supplied logo and independent changes:
Copyright (C) 2026 YASSERAPPS
Channel: https://t.me/YasserAppsIQ

This derivative must preserve original author credits and make its modified
corresponding source available to users under AGPL-3.0. The YASSERAPPS name
and original visual identity do not transfer ownership of the Vyxel code.
No premium/proprietary theme assets are included.
""",encoding='utf-8')
(ROOT/'YASSERAPPS_ORIGIN.md').write_text("""# YASSERAPPS derivation

Derived from https://github.com/NikhilKain/vyxel-apps
License: GNU AGPL v3.0, see LICENSE.
Copyright (C) 2026 Nikhil (original software).
Copyright (C) 2026 YASSERAPPS (branding and original changes).
Official channel: https://t.me/YasserAppsIQ
Package ID: com.yasserapps.store

No rights to original Vyxel source code or third-party application APKs are claimed.
""",encoding='utf-8')
print('YASSERAPPS branding overlay completed. APK not built by this script.')
