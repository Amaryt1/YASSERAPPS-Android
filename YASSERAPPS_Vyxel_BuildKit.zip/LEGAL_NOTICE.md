YASSERAPPS original branding and modification kit © 2026 YASSERAPPS.
This toolkit is designed to patch the Vyxel Apps open-core client. The original
client remains copyright © 2026 Nikhil and licensed under GNU AGPL-3.0.
Redistribution of the modified APK must comply with the original license.
No proprietary Vyxel premium skins or third-party APKs are included here.
